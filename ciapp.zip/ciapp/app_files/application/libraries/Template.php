<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Template Class
 *
 * Using string as view 
 * $string = 'The string to be embedded here!'
 * $data = array(
 * 	'title' => 'Title goes here',
 * 	'body'  => $string
 * );
 * $this->template->load('default', null, $data);
 *
 * Using file as view
 * $view_file = 'content'
 * $data = array( 
 * 	'title' => 'Title goes here',
 * );
 * $this->load->library('template');
 * $this->template->load('default', $view_file, $data);
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Template
 * @author	developerssm6
 * @email	developerssm6@gmail.com
 */
class Template {

	function __construct() {
		$this->ci =& get_instance();
	}
	
	function load($tpl_view, $body_view = null, $data = null) {
		if ( ! is_null( $body_view ) ) {
			if ( file_exists( VIEWPATH.$tpl_view.'/'.$body_view ) ) {
				$body_view_path = $tpl_view.'/'.$body_view;
			} else if ( file_exists( VIEWPATH.$tpl_view.'/'.$body_view.'.php' ) ) {
				$body_view_path = $tpl_view.'/'.$body_view.'.php';
			} else if ( file_exists( VIEWPATH.$body_view ) ) {
				$body_view_path = $body_view;
			} else if ( file_exists( VIEWPATH.$body_view.'.php' ) ) {
				$body_view_path = $body_view.'.php';
			} else {
				if ( ENVIRONMENT !=='development' ) {
					// show production error page
					show_404();
					return false;
				} else {
					show_error('Unable to load the requested file: ' . $tpl_view.'/'.$body_view.'.php');
				}
			}
			//get parsed view as string
			$body = $this->ci->load->view($body_view_path, $data, TRUE);
			
			if ( is_null($data) ) {
				$data = array('body' => $body);
			} else if ( is_array($data) ) {
				$data['body'] = $body;
			} else if ( is_object($data) ) {
				$data->body = $body;
			} else {
				return false;
			}
		}
		//load the view
		if ( file_exists( VIEWPATH.'templates/'.$tpl_view.'.php' ) ) {
			$this->ci->load->view('templates/'.$tpl_view, $data);
		} else {
			if ( ENVIRONMENT !=='development' ) {
				// show production error page
				show_404();
				return false;
			} else {
				show_error('Unable to load the requested template file: ' . $tpl_view.'.php');
			}
		}
	}
}