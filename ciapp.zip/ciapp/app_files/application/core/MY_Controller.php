<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
	public $data =array();
	
	function __construct() {
		parent::__construct();
		$this->load->helper('url'); // for redirect()
		$this->load->library('session');
		
		$current_page = uri_string();
		
		$is_installed = file_exists(APPPATH.'config'.DIRECTORY_SEPARATOR.'site_config.php');
		
		if ( $is_installed == false && ENVIRONMENT == 'production') {
			// show maintance page
			show_error('Site under maintenance. Please visit later', 503, 'Service Unavailable.');
		} else if ( $is_installed == false && ENVIRONMENT == 'development') {
			// show installation page
			die('not installed');
		}
		$this->config->load('site_config');
		$this->load->library('session');
		$this->check_db();

		
		
		$this->data['errors']=array();
		$this->data['site_name']=config_item('site_name');
		
		#$this->output->enable_profiler(TRUE);     
	}
	
	private function check_db() {
		## Check Database
		@$this->load->database();
		$errors = $this->db->error();
		$error_code =  $errors['code'] ;
		if ( ENVIRONMENT == 'production' && $error_code ) {
			
			// database error show maintenance page
			show_error('Site under maintenance. Please visit later', 503, 'Service Unavailable.');
			
		}
		
		if ( $error_code == 0 && !$this->db->database) {
			show_error('Database not found. Please check database configuration', 503, 'Database Not Found.');
		}
		
		switch ($error_code) {
			case 2002:
			show_error('Database server not found. Please start server or check database configuration', 503, 'Database Server Not Found.');
			break;
			
			case 1045:
			show_error('Database Access Denied. Please check database configuration', 503, 'Database Access Denied.');
			break;
			
			case 1049:
			show_error($this->db->database . ' not found @'.$this->db->hostname. '. Please check database configuration', 503, 'Database Not Found.');
			break;
		}
	}
}