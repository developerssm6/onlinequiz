<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model {
	
	public $logged_in = null;

	function __construct() {
		parent::__construct();

		$this->logged_in = $this->session->userdata('logged_in');
	}
}