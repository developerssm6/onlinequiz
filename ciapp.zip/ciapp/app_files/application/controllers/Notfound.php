<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class notfound extends MY_Controller {
	function __construct() {
		parent::__construct();
		$this->load->library('template');
		$this->data['title'] = "404 Page Not Found";
	}
	public function index() {
		$template_file = $this->uri->segment(1) === 'admin' ? 'admin_error_template' : 'user_error_template';
		$this->template->load($template_file, 'custom_errors/error_404', $this->data);
	}
}